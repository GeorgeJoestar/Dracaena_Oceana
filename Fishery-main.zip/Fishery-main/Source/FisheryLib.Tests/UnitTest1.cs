global using System;
global using Xunit;

namespace FisheryLib.Tests;

public class UnitTest1
{
	[Fact]
	public void Test1()
	{

	}
}